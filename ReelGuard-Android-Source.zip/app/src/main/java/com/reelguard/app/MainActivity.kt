package com.reelguard.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("reelguard", MODE_PRIVATE) }
    private lateinit var countView: TextView
    private lateinit var goalView: TextView
    private lateinit var statusView: TextView
    private lateinit var goalInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }

        val title = TextView(this).apply {
            text = "ReelGuard"
            textSize = 30f
            setTextColor(0xFF172033.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Your mindful scrolling dashboard"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF667085.toInt())
        }
        root.addView(subtitle, matchWrap())

        countView = TextView(this).apply {
            textSize = 56f
            gravity = Gravity.CENTER
            setTextColor(0xFF5B4BDB.toInt())
            setPadding(0, 38, 0, 0)
        }
        root.addView(countView, matchWrap())

        val countLabel = TextView(this).apply {
            text = "Estimated Reels activity today"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF344054.toInt())
        }
        root.addView(countLabel, matchWrap())

        goalView = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 12)
            setTextColor(0xFF344054.toInt())
        }
        root.addView(goalView, matchWrap())

        statusView = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(12, 16, 12, 16)
            setTextColor(0xFF344054.toInt())
        }
        root.addView(statusView, matchWrap())

        val goalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        goalInput = EditText(this).apply {
            hint = "Daily limit (e.g. 30)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        goalRow.addView(goalInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val saveGoal = Button(this).apply {
            text = "Save limit"
            setOnClickListener {
                val value = goalInput.text.toString().toIntOrNull()
                if (value == null || value !in 1..999) {
                    Toast.makeText(this@MainActivity, "Enter a limit from 1 to 999", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putInt("goal", value).apply()
                    refresh()
                    Toast.makeText(this@MainActivity, "Daily limit saved", Toast.LENGTH_SHORT).show()
                }
            }
        }
        goalRow.addView(saveGoal)
        root.addView(goalRow, matchWrap())

        val enable = Button(this).apply {
            text = "Enable activity estimate"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(enable, matchWrap())

        val refreshButton = Button(this).apply {
            text = "Refresh dashboard"
            setOnClickListener { refresh() }
        }
        root.addView(refreshButton, matchWrap())

        val note = TextView(this).apply {
            text = "Note: This is an estimate, not an official Instagram count. Some Reels may be missed and other Instagram activity may occasionally be counted. Data stays on this device."
            textSize = 12f
            setTextColor(0xFF667085.toInt())
            setPadding(4, 24, 4, 0)
        }
        root.addView(note, matchWrap())

        setContentView(root)
        refresh()
    }

    private fun refresh() {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (prefs.getString("day", "") != today) {
            prefs.edit().putString("day", today).putInt("count", 0).apply()
        }
        val count = prefs.getInt("count", 0)
        val goal = prefs.getInt("goal", 30)
        countView.text = count.toString()
        goalView.text = "Daily limit: $goal"
        statusView.text = if (count >= goal) {
            "Daily limit reached. Consider taking a break."
        } else {
            "You have ${goal - count} estimated views left before your limit."
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
