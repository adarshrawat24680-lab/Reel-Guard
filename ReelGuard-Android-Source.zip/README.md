# ReelGuard

A small native Android app that provides a **best-effort estimate** of Instagram Reels activity.

## Features
- Daily estimated activity counter
- User-set daily limit
- On-device preferences only
- Optional Android Accessibility Service

## Important limitations and privacy
- Instagram does not provide a public API that reports how many Reels a person watched.
- The counter checks short-lived accessibility event labels for the word “reel”. It can miss Reels or count unrelated events.
- It is an estimate, not a reliable or official watch count.
- The app does not upload activity, save screenshots, or intentionally store event text or messages.
- Android Accessibility access is powerful. Enable it only after reading Android's disclosure. You can turn it off in Android Settings at any time.

## Build
This repository contains source code, not a ready-made APK. Build it with Android Studio or a compatible Android build environment using Gradle 8.9 and JDK 17, then install and test the debug APK on a device.

## Package
`com.reelguard.app`
