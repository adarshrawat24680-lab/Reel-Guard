package com.reelguard.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReelCounterService : AccessibilityService() {
    private var lastCountAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != "com.instagram.android") return

        // Only inspect transient event labels for the word "reel"; never store event text.
        // This is a best-effort heuristic and can miss or misclassify activity.
        val labelLooksLikeReel = event.text.any {
            it.toString().contains("reel", ignoreCase = true)
        }
        if (!labelLooksLikeReel) return

        val now = System.currentTimeMillis()
        if (now - lastCountAt < 2500L) return
        lastCountAt = now

        val prefs = getSharedPreferences("reelguard", MODE_PRIVATE)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (prefs.getString("day", "") != today) {
            prefs.edit().putString("day", today).putInt("count", 0).apply()
        }
        val newCount = prefs.getInt("count", 0) + 1
        prefs.edit().putInt("count", newCount).apply()

        val goal = prefs.getInt("goal", 30)
        if (newCount == goal) {
            Toast.makeText(this, "ReelGuard: Your daily limit has been reached.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onInterrupt() = Unit
}
